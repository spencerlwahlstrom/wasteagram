class PostDTO{
  late DateTime date;
  late String photo;
  late int items;
  late double lat;
  late double long;
}